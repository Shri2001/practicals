package singletonpackage;

public class HotterSingleton extends Singleton
{
 private HotterSingleton()
 {
   super();
 }
}