function validateform(){
var email = document.getElementById("email").value;
var pass = document.getElementById("pass").value; var
regEmail = /^([a-zA-Z0-9\._]+)@([a-z]+)(.[a-z]+)?$/;

//if Fields are empty
if(email.length == 0){
alert("All Fields are Mandatory");
return false;
}
else if(pass.length == 0){
alert("All Fields are Mandatory");
return false;

}
else if(!regEmail.test(email)){
alert("Enter Name Format Correctly \"First Name Last
Name\"");
return false;
}
else{
alert("Validation Successfull");
return true;
}
}