var http = require('http');
 
var fs = require('fs');
 
 
var server = http.createServer(function(req,res){
 
    //fs.open( filename, , mode[r = read & r+ = readwrite], callback )
 
    fs.open('Sample.txt','r',function(err,fd){ 
 
        if(err){
 
            console.error(err);
 
            return res.end("404 File Not Found");
 
        }
 
        else{
 
            console.log("File Open Successfully");
 
            fs.readFile('sample.txt',function(err,data){
 
                if(!err){
 
                    console.log('File Read Successfully');
 
                    res.end(data);
 
                    fs.close(fd);
 
                }
 
                else{
 
                    console.log('Read File is not possible');
 
                }
 
            });
 
        }
 
    });
 
}).listen(8080);