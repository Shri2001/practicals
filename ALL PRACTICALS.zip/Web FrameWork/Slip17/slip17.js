//npm install express var
express = require('express'); var
app = express(); var PORT =
8080;
app.get('/', function (req, res) {
res.download('test.txt', function (error) {
console.log("Error : ", error)
});
});

app.listen(PORT, function (err) {
if (err) console.log(err);
console.log("Server listening on PORT", PORT);
});