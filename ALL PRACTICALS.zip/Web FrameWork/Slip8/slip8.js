//npm install mysql2 var
mysql = require('mysql2');

var con = mysql.createConnection({
host: "localhost", port: 3306,user: "root", password:"sanket612"
});

con.connect(function (err) {
if (err) throw err;
console.log("Connected!");
con.query("CREATE DATABASE mydb1", function (err, result) {
if (err) throw err;
console.log("Database created");
});
var sql = "CREATE TABLE mydb1.customers (name VARCHAR(255),address VARCHAR(255))";
con.query(sql, function (err, result) {
if (err) throw err;
console.log("Table created");

});
});