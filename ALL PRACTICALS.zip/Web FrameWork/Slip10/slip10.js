//npm install mysql2 var
mysql = require('mysql2');

var con = mysql.createConnection({
host: "localhost", port: 3306,
user: "root", password:"sanket612", database:"mydb"
});
con.connect(function (err) {
if (err) throw err;
console.log("Connected!");
var sql = "INSERT INTO student (name, address) VALUES ('Sanket','Rajgurunager'), ('Saurabh', 'Satara'),('Ram','Nigdi')";
con.query(sql, function (err, result) {

if (err) throw err;
console.log(result);
});
con.query("SELECT * FROM student", function (err, result, fields)
{
if (err) throw err;
console.log(result);
});
});